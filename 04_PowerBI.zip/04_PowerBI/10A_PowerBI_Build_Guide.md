# 10A — Power BI Build Guide

## Objective

Build the working Power BI decision-support product using the five import-ready tables in this package.

## Import these tables

1. `Dim_Borough`
2. `Fact_Labour_Market`
3. `Fact_Priority`
4. `Dim_Cluster`
5. `Fact_Intervention`

## Relationships

Create these single-direction relationships:

- `Dim_Borough[borough_code]` 1 → * `Fact_Labour_Market[borough_code]`
- `Dim_Borough[borough_code]` 1 → * `Fact_Priority[borough_code]`
- `Dim_Borough[borough_code]` 1 → * `Fact_Intervention[borough_code]`
- `Dim_Cluster[cluster_id]` 1 → * `Fact_Intervention[cluster]`

Do not create a direct relationship between `Fact_Priority` and `Fact_Intervention`.

## Important modelling note

`Fact_Labour_Market` contains 32 boroughs because the City of London has missing borough-level unemployment/inactivity observations in the analytical source. `Dim_Borough` intentionally retains all 33 London borough records so the geography remains complete.

Do not replace missing City of London values with zero.

## Recommended report pages

### Page 1 — Executive Overview

Purpose: Where are the priority labour-market areas?

Recommended visuals:
- High Priority Boroughs KPI
- Robust High Priority Boroughs KPI
- Average unemployment
- Average inactivity
- Average jobs density
- borough priority map
- priority ranking table
- priority tier distribution

### Page 2 — Borough Diagnostic

Purpose: Why is this borough a priority?

Add a borough slicer using `Dim_Borough[borough_name]`.

Show:
- unemployment rate
- inactivity rate
- jobs density
- priority score
- priority rank
- priority tier
- robustness status
- cluster profile
- intervention theme
- comparison with London

### Page 3 — Priority & Intervention

Purpose: What should decision-makers focus on?

Show:
- priority ranking
- tier
- robust priority
- cluster profile
- intervention theme
- suggested KPI
- rationale

## Build sequence

1. Import the five tables.
2. Set data types.
3. Create relationships.
4. Add the DAX measures from `09B_DAX_Measures.dax`.
5. Apply the formatting rules from 09B.
6. Build Page 1.
7. Build Page 2.
8. Build Page 3.
9. Apply the UX rules from 09C.
10. Run every applicable test in 09D.
11. Reconcile headline values against `Fact_Priority` and the validated analytical workbook.

## Validation principle

Power BI is the presentation layer. The validated analytical outputs are the reference values. If Power BI disagrees with the analytical outputs, investigate the model or DAX rather than changing the reference output merely to make the dashboard match.

## Release gate

Do not describe the dashboard as production-ready until:
- the model reconciles,
- all key measures are tested,
- filters behave correctly,
- the three pages are understandable,
- accessibility checks pass,
- narrative wording avoids unsupported causal claims.
